<?php 
    $key = "05d0a43a34232da067f2db4e7335fe40770edc4a619f7e5eaf9a2ef5d9384a3a";
?>