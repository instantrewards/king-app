<?php
$servername="localhost";
$dbname = "cash2";
$username = "cash2";
$password = "123456";

$link=mysqli_connect($servername,$username, $password,$dbname);

if(!$link)
{
    echo "error";
}

$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
?>