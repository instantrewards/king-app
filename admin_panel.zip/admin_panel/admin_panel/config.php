<?php
// Firebase API Key
define('FIREBASE_API_KEY', 'AAAA9muE9Ko:APA91bHLCj5ONv_JbTPYjvLYuJKgmhr8-sWSnUMH6BJaxpkSRJTWjlAzROr6W4Pr56mXY6TroF3Rh2UkndLzFT3Zo3Ja9jashPBQWQxv2tae3CLz--eqcrnYXD_a1705E-S1wqrfaeyj');
?>