<?php
$demo = false; // change this to false for live and true for demo pannel.
$isWebsite = true; // true for website code false for codecanyon code
?>